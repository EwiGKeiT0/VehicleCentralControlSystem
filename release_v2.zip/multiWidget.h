#ifndef MULTIWIDGET_H
#define MULTIWIDGET_H

#include "naviwidget.h"
#include "browserwidget.h"
#include "indexWidget.h"
#include "chatWidget.h"
#include "mediawidget.h"
#include "settingwidget.h"

#endif // MULTIWIDGET_H
